import requests

response = requests.get("http://universities.hipolabs.com/search?country=Latvia")

schools = response.json()


# def sortParameter(e):
#     return e["name"]

# schools.sort(key=sortParameter)

# for skol in schools:
#     if skol["domains"][0] == "mit.edu":
#         print(skol["name"])

