import requests

# response = requests.get("https://catfact.ninja/fact")

# catFact = response.json()

# print(catFact["fact"])


name = input("ievadi vardu! ")

while name != "":
    response = requests.get("https://api.nationalize.io?name=" + name)
    res = response.json()
    print(res)
    # print(name, "dzīvos līdz", age, "gadu vecumam")
    name = input("ievadi vardu! ")

