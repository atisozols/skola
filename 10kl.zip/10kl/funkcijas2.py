def kvadrats(x):
    y = x * x
    return y

print(kvadrats(5))
print(kvadrats(12))