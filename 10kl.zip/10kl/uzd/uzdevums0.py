# Dots divciparu skaitlis. Samainit vietam ciparus.
x = int(input('ievadiet skaitli '))

vieni = x % 10
desmiti = (x - vieni) / 10

# print(vieni)
# print(desmiti)

print(int(vieni * 10 + desmiti))

