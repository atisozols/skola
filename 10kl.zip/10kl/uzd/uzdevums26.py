s = 'baranka'
a = 'a'
# for i in range(len(s)):
#     print(chr(ord(s[i])-3), end='')
print(s.replace('a', 'apa'))


