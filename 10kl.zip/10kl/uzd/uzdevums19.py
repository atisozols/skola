a = [[0, 0, 1],
     [0, 1, 0],
     [1, 0, 0]]

for i in range(len(a)):
    for j in range(len(a[i])):
        print(a[i][j], end=' ')
    print()

# for j in range(len(a[1])):
#     print(a[1][j], end=' ')
#
# print()
#
# for i in range(len(a)):
#     print(a[i][1])
