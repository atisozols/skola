# lietotajs ievada divus skaitlus, programma izvada lielako

x = int(input('ievadi skaitli '))
y = int(input('ievadi skaitli '))

if x > y:
    print(x)
elif y > x:
    print(y)
else:
    print('vienadi')
