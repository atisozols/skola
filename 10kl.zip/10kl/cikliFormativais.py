# Ievada n. Programma, kas izvada visus skaitļus no n līdz 2n.

# Programma, kas saskaita visus skaitļus no 1 līdz 100.

# Izvadīt visus nepāra skaitļus dilstošā secībā no 25 līdz 1.

# Izmantojot ciklu, izveidot programmu, kas liek ievadīt piecus skaitļus
# un izvada to summu.

# Vada skaitļus, kamēr ievada nulli. izvadīta skaitļu summa.