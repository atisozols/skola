# Klase Kubs, kurai tiek padota viena vērtība - šķautnes garums.
# Iekšējās funkcijas, kas aprēķina kuba tilpumu un virsmas laukumu.

# Klase Circle, kurai konstruktorā padod rādiusu.
# Iekšējās funkcijas, kas atgriež laukumu un r. l. garumu.
# Definēt matemātiskās summas funkcionalitāti (__add__), 
# lai, saskaitot divus Circle objektus, tiktu iegūts 
# riņķis, kura laukums ir abu saskaitāmo riņķu laukums. 
# (tātad kāds būs rādiuss?!)

# Nodemonstrēt klašu darbību