# 1N. Programma, kas izvada visus pāra skaitļus no 20 līdz 37. 

# for s in range(20, 37):
#     if s % 2 == 0:
#         print(s)

# 2N. Lietotājs ievada divus skaitļus, programma izvada, kuram no skaitļiem ir mazāka ciparu summas vidējā vērtība

# a = int(input("ievadi a:")) 
# b = int(input("ievadi b:")) 

# def c_sum(s):

# c_sum1 = c_sum(a)
# c_sum2 = c_sum(b)

# if c_sum1 < c_sum2:
#     print("pirma cipara summas videjais ir mazaks" c_sum1)
#     elif c_sum2 < c_sum1:
#         print("otra cipara summas videjais ir mazaks" c_sum2)
#         else:
#             print("abiem ir vienads videjais")

# 3N.  Programma, kas pieprasa vadīt skaitļus, kamēr neievada 0. Tiek saskaitīti visi ievadītie nepāra skaitļi.

# b = 0

# while True:
#     a = int(input("ievadi 0, lai beigtu:")) 
#     if a == 0:
#       break
#     if a % 2 != 0:
#         b += a
# print("nepara summa ir", b)

# 4. Lietotājs ievada skaitli, programma nosaka šī skaitļa pirmo trīs ciparu vidējo vērtību.
# Piemērs: 1326569 -> 132 -> 2.0

# b = input("ievadiet: ")

# videjais = 

# print("pirmo tris ciparu videja vertiba", b)
 
# 5. Lietotājs ievada skaitli. Ja skaitlis ir pirmskaitlis, izvadīt tā ciparu summu, citādi izvadīt lielāko ciparu

# a = int(input("ievadi:")) 

# def pirmskaitlis(a):
#     if a <= 1:
#         return False
#     if a <= 3:
#         return True
#     if a % 2 == 0 or a % 3 == 0:
#         return False
#         i = 5
#         while i * i <= a:
#             if a % i == 0 or a % (i + 2) == 0:
#                 return False
#                 i += 6
#                 return True

#     if pirmskaitlis(a):

# galigi nesagaja ^


