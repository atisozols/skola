# 1P
# for i in range (-1, -11, -11):
#     print(i)
# 2P
# summa = 0
# x = int(input('skaitlis x: '))
# y = int(input('skaitlis y: '))
# summa = summa + x 
# summa = summa + y 

# if summa + x  > summa + y:
#     print(x)
# elif summa + y > summa + x:
#     print(y)
# 3P
skaits = 0
sum = 0 
n = int(input('n: '))
max = n
while n != 0:
    if n % i == 0:
        if i % 2 == 0:
            paraSkaitlis
    print(max)

    
