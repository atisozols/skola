# 1.P. Programma, kas izvada visus skaitļus no -1 līdz -10 dilstošā secībā
# for i in range(-1, -10-1, -1):
#     print(i)

#2.P.Lietotājs ievada divus skaitļus, programma izvada, kuram no šiem skaitļiem ir lielāka ciparu summa.
# a = int(input("ievadi a: "))
# b = int(input("ievadi b: "))
# x=0
# y=0
# d = 0
# z = 0
# c=0
# p=0
# if a % 10 == x:
#       if y== a-x % 10:
#         if x + y == d:
#             if b % 10 == z:
#                 if c== a-z % 10:
#                      if z + c == p:
      

# 3P. Programma, kas pieprasa vadīt skaitļus, kamēr neievada 0. No ir ievadītajiem skaitļiem atrast lielāko pāra skaitli.
# max = 0
# a = int(input("ievadi a: "))
# while a != 0:
#     a = int(input("ievadi a: "))
#     if a % 2 == 0:
#         max > a
#         print(max)
    
    

