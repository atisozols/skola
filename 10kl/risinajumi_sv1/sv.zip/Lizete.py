# 1.N

# for i in range(20, 37):
#     if i % 2 == 0:
#         print(i)

#2.N
# summa = 0
# a = int(input("a: "))
# b = int(input("b: "))

# for


# 3N

# n = int(input("n: "))
# while n != 0:
#   n = int(input("n: "))
# n % 2 != 0
# sum = sum + n
      
# print(sum)


# 5.

# n = int(input("n: "))
# if n % n == 0
# if n % 1 == 0
