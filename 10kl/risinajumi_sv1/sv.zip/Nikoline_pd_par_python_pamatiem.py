#1N. Programma, kas izvada visus pāra skaitļus no 20 līdz 37.
# n=int(input("n:"))
# for i in range (20, 37, 2):
#     print(i)
#2N Lietotājs ievada divus skaitļus, programma izvada, kuram no skaitļiem ir mazāka ciparu summa.
# summa=0
# a=int(input("a:"))
# b=int(input("b:"))
# while a>0:
#     p=a%10 
#     sum += p
#     p=a//10
# while b>0:
#     p=b%10 
#     sum += p
#     p=b//10
#     if a > b:
#         print(sum)
#     else:
#         print(sum)
#3N. Programma, kas pieprasa vadīt skaitļus, kamēr neievada 0. Tiek saskaitīti visi ievadītie nepāra skaitļi.
# sum=0
# n=int(input("n:"))
# while n!=0:
#     sum += n
#     if n%2!=0:
#         print(sum)
#4. Lietotājs ievada skaitli, programma nosaka šī skaitļa pirmo trīs ciparu vidējo vērtību.
# n=int(input("n:"))
# sum=0
# while n!=0:
#     sum += n
#     n=int(input("n:"))
#     avg=(n+n+n)//3
#     print(avg)
#5. Lietotājs ievada skaitli. Ja skaitlis ir pirmskaitlis, izvadīt tā ciparu summu, citādi izvadīt lielāko ciparu
# a=0
# n=int(input("n:"))
# for i in range(1,n+1):
#     if n%i==0:
#         a=a+1
#     if  a==a+1:
#      x=int(input("x:"))
#     summa=summa+x
# print(summa)
# ifelse:print(a)

